const express=require("express");
const bodyParser=require("body-parser");


const app=express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static("css"));
app.set('view engine','ejs');

app.get('/',(req,res)=>{



    res.render('bmi',{Result: " ",ww:"",hh:"",aa:""});


})
 
function getBMI(w,h){
    r=(w*10000)/(h*h);
return r;
}

app.post('/',(req,res)=>{
 

    
    w=Number(req.body.weight);
    h=Number(req.body.height);
    a=Number(req.body.age);
    resbmi="Bmi is "+getBMI(w,h);

   res.render('bmi',{Result:resbmi,ww:w,hh:h,aa:a})
 

})

app.listen(3000,function(){

    console.log("3000 server is running");
})